-- ══════════════════════════════════════════════════════════════
-- Sistema de Incentivos por Tienda
-- Migración inicial — ejecutar en Supabase SQL Editor
-- ══════════════════════════════════════════════════════════════

-- 1. CONFIGURACIÓN DE COLUMNAS (mapeo Rapifac → sistema)
create table if not exists column_mapping (
  id uuid primary key default gen_random_uuid(),
  col_sucursal text not null,       -- nombre columna = tienda/sucursal
  col_total    text not null,       -- nombre columna = monto total
  col_fecha    text not null,       -- nombre columna = fecha
  col_cajero   text,                -- nombre columna = cajero/vendedor (opcional)
  fuente       text default 'rapifac',
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- 2. TIENDAS Y METAS
create table if not exists tiendas (
  id           uuid primary key default gen_random_uuid(),
  nombre       text not null unique,
  venta_ant    numeric(12,2) default 0,  -- venta año anterior base
  crec_obj     numeric(5,4) default 0.12, -- crecimiento objetivo (0.12 = 12%)
  activa       boolean default true,
  created_at   timestamptz default now()
);

-- 3. TIERS DE INCENTIVO INDIVIDUAL (vs meta)
create table if not exists tiers_meta (
  id        uuid primary key default gen_random_uuid(),
  desde_pct integer not null,
  hasta_pct integer not null,
  nivel     text not null,
  bono_ind  numeric(8,2) default 0,
  pool_grp  numeric(8,2) default 0,
  orden     integer default 0
);

-- 4. TIERS YoY (vs año anterior)
create table if not exists tiers_yoy (
  id        uuid primary key default gen_random_uuid(),
  desde_pct integer not null,
  hasta_pct integer not null,
  nivel     text not null,
  bono_adic numeric(8,2) default 0,
  orden     integer default 0
);

-- 5. PARÁMETROS GLOBALES
create table if not exists parametros (
  clave text primary key,
  valor text not null,
  descripcion text
);

-- 6. EMPLEADAS
create table if not exists empleadas (
  id         uuid primary key default gen_random_uuid(),
  nombre     text not null,
  activa     boolean default true,
  created_at timestamptz default now()
);

-- 7. HORARIOS POR MES (empleada × tienda × mes)
create table if not exists horarios (
  id          uuid primary key default gen_random_uuid(),
  mes         text not null,           -- 'YYYY-MM'
  empleada_id uuid references empleadas(id),
  tienda_id   uuid references tiendas(id),
  horas       numeric(6,1) default 0,
  unique(mes, empleada_id, tienda_id)
);

-- 8. VENTAS PROCESADAS (resultado del CSV Rapifac)
create table if not exists ventas_mes (
  id          uuid primary key default gen_random_uuid(),
  mes         text not null,           -- 'YYYY-MM'
  tienda_id   uuid references tiendas(id),
  total_ventas numeric(12,2) default 0,
  fuente_archivo text,
  procesado_at timestamptz default now(),
  unique(mes, tienda_id)
);

-- 9. VENTAS AÑO ANTERIOR (ingreso manual o histórico)
create table if not exists ventas_ant (
  id          uuid primary key default gen_random_uuid(),
  mes         text not null,           -- 'YYYY-MM' del año anterior
  tienda_id   uuid references tiendas(id),
  total_ventas numeric(12,2) default 0,
  unique(mes, tienda_id)
);

-- 10. RESULTADOS DE BONOS (calculados)
create table if not exists resultados (
  id            uuid primary key default gen_random_uuid(),
  mes           text not null,
  empleada_id   uuid references empleadas(id),
  bono_meta     numeric(8,2) default 0,
  bono_yoy      numeric(8,2) default 0,
  bono_combinado numeric(8,2) default 0,
  pool_grupal   numeric(8,2) default 0,
  bono_reviews  numeric(8,2) default 0,
  total_bono    numeric(8,2) default 0,
  calculado_at  timestamptz default now(),
  unique(mes, empleada_id)
);

-- 11. GOOGLE REVIEWS POR MES
create table if not exists reviews (
  id        uuid primary key default gen_random_uuid(),
  mes       text not null,
  tienda_id uuid references tiendas(id),
  score     numeric(3,1),
  unique(mes, tienda_id)
);

-- ── DATOS INICIALES ──────────────────────────────────────────

-- Parámetros por defecto
insert into parametros values
  ('peso_meta',    '0.60', '% del bono combinado por cumplimiento vs meta'),
  ('peso_yoy',     '0.40', '% del bono combinado por crecimiento vs año anterior'),
  ('regla_multi',  'PRORRATEO', 'PRORRATEO | PRINCIPAL | PROMEDIO'),
  ('peso_reviews', '0.15', '% adicional sobre bono por Google Reviews'),
  ('score_min',    '4.2',  'Score mínimo para activar bono reviews'),
  ('score_obj',    '4.7',  'Score objetivo para bono reviews máximo'),
  ('usar_reviews', 'SI',   'SI activa el componente de reviews')
on conflict (clave) do nothing;

-- Tiers individuales vs meta (por defecto)
insert into tiers_meta (desde_pct, hasta_pct, nivel, bono_ind, pool_grp, orden) values
  (0,   79,  'Sin bono',           0,   0,   1),
  (80,  94,  'Near target',      150,   0,   2),
  (95,  104, 'On target',        300, 200,   3),
  (105, 114, 'Stretch',          500, 350,   4),
  (115, 999, 'Exceeds stretch',  700, 500,   5)
on conflict do nothing;

-- Tiers YoY (por defecto)
insert into tiers_yoy (desde_pct, hasta_pct, nivel, bono_adic, orden) values
  (-999, -1,  'Cayó vs año ant.',          0,  1),
  (0,    4,   'Crec. mínimo (0-4%)',       50, 2),
  (5,    9,   'Crec. moderado (5-9%)',    100, 3),
  (10,   19,  'Crec. sólido (10-19%)',   200, 4),
  (20,   999, 'Crec. excepcional (20%+)', 350, 5)
on conflict do nothing;
